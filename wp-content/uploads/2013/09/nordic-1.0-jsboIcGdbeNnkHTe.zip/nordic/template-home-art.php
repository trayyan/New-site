<?php
/*Template Name:Home (Art)*/
get_header();
?>

<div class="galleryMain left-space">

	<div class="holder">
        <div class="figure_container">
            <?php
                $arguments = array();
                $arguments["post_type"] = "portfolio";
                $arguments["posts_per_page"] = 4;
                $the_query = new WP_Query( $arguments );
                while ( $the_query->have_posts() ) :  $the_query->the_post();
            ?>
                <figure class="post-thumb">
                    <div>
                        <?php the_post_thumbnail("work_art_slide"); ?>
                        <a href="<?php the_permalink(); ?>">
                        <div class="hover-state">
                            <p class="likes"><i class="icon-heart"></i> <?php echo get_likes(); ?></p>
                            <p class="cont"><i class="icon-search"></i></p>
                        </div>
                        </a>
                    </div>
                </figure>
            <?php endwhile; ?>
        </div>
		<div class="floor">
			<div>
				<a href="#" class="art_prev"><i class="icon-angle-left"></i></a>
				<a href="#" class="art_next"><i class="icon-angle-right"></i></a>
			</div>
		</div>
	</div>

    <script type="text/javascript">
        jQuery(document).ready(function($){
            $("#footer").hide();
            current_slide = $("figure:eq(0)");

            $(".galleryMain").serialScroll({
                items : "figure",
                prev : "a.art_prev",
                next : "a.art_next",
                lock : false,
                stop : true,
                offset : -120,
                duration : 500
            });
        });
    </script>
</div>

<?php get_footer(); ?>