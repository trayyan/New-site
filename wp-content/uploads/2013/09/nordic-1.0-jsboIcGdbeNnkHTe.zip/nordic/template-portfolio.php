<?php if(isset($_REQUEST["um_page"])): ?>
    <div>
        <div class="column-4 row filterable">
            <?php
            $arguments = array();
            $arguments["post_type"] = "portfolio";
            $arguments["posts_per_page"] = 12;
            $arguments["paged"] = $_REQUEST["um_paged"];
            $the_query = new WP_Query( $arguments );
            while ( $the_query->have_posts() ) :  $the_query->the_post();
                $terms = wp_get_post_terms( $post->ID,"portfolio_category" );
                $terms_html_array = array();
                $terms_id_array = array();
                $term_classes = "";
                foreach($terms as $t){
                    $term_name = $t->name;
                    $term_link = get_term_link($t->slug,$t->taxonomy);
                    array_push($terms_html_array,"<a href='{$term_link}'>{$term_name}</a>");
                    array_push($terms_id_array,$t->slug);
                    $term_classes .= "um_".$t->slug." ";
                }
                $terms_html_array = implode(", ",$terms_html_array);
                ?>
                <div class="column project_block post_block col-sm-3 mix_all <?php echo $term_classes; ?>" data-filter='<?php echo implode(" ",$terms_id_array); ?> mix_all'>
                    <div>
                        <?php the_post_thumbnail("work_post"); ?>
                    </div>
                    <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                    <ul>
                        <?php if($terms_html_array): ?>
                            <li><i class='icon-angle-right'></i><?php echo $terms_html_array; ?></li>
                        <?php endif; ?>
                    </ul>
                </div>
            <?php endwhile; wp_reset_postdata(); ?>
        </div>

        <div class="column-2 row filterable">
            <?php
            $arguments = array();
            $arguments["post_type"] = "portfolio";
            $arguments["posts_per_page"] = 4;
            $arguments["paged"] = $_REQUEST["um_paged"];
            $the_query = new WP_Query( $arguments );
            while ( $the_query->have_posts() ) :  $the_query->the_post();
                $terms = wp_get_post_terms( $post->ID,"portfolio_category" );
                $terms_html_array = array();
                $terms_id_array = array();
                $term_classes = "";
                foreach($terms as $t){
                    $term_name = $t->name;
                    $term_link = get_term_link($t->slug,$t->taxonomy);
                    array_push($terms_html_array,"<a href='{$term_link}'>{$term_name}</a>");
                    array_push($terms_id_array,$t->slug);
                    $term_classes .= "um_".$t->slug." ";
                }
                $terms_html_array = implode(", ",$terms_html_array);
                ?>
                <div class="column project_block post_block col-sm-6 <?php echo $term_classes; ?>" data-filter='<?php echo implode(" ",$terms_id_array); ?> mix_all'>
                    <div>
                        <?php the_post_thumbnail("work_post_medium"); ?>
                    </div>
                    <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                    <ul>
                        <?php if($terms_html_array): ?>
                            <li><i class='icon-angle-right'></i><?php echo $terms_html_array; ?></li>
                        <?php endif; ?>
                    </ul>
                </div>
            <?php endwhile;wp_reset_postdata(); ?>
        </div>
    </div>
<?php die();endif;?>
<?php
/*Template Name:Portfolio*/
get_header();
?>
<div class="container protfolio-page left-space">
	<div class="row">
		<div class="col-sm-12">
			<h5 class="section-title"><?php the_title(); ?></h5>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-12 projects-intro">
			<h1><?php the_field("page_heading"); ?></h1>
			<h4><?php the_field("page_sub_heading"); ?></h4>
		</div>
	</div>

    <?php
        $terms = get_terms("portfolio_category");
        if($terms):
    ?>
	<div class="row categories-p">
		<ul class="col-sm-12">
			<li><a href="#" data-filter="mix_all" class="active"><?php _e("All","um_lang"); ?></a></li>
            <?php foreach($terms as $term): ?>
			    <li><a href="#" data-filter="um_<?php echo $term->slug; ?>"><?php echo $term->name; ?></a></li>
			<?php endforeach; ?>
		</ul>
	</div>
    <?php endif; ?>

</div>
<div class="projects container left-space">
	<div class="col-switcher">
		<a href="#" class="col-four project_col_four active"><i class="icon-th"></i></a>
		<a href="#" class="col-two project_col_two"><i class="icon-th-large"></i></a>
	</div>


    <div class="column-4 row filterable">
        <?php
        $arguments = array();
        $arguments["post_type"] = "portfolio";
        $arguments["posts_per_page"] = 12;
        $the_query = new WP_Query( $arguments );
        while ( $the_query->have_posts() ) :  $the_query->the_post();
            $terms = wp_get_post_terms( $post->ID,"portfolio_category" );
            $terms_html_array = array();
            $terms_id_array = array();
            $term_classes = "";
            foreach($terms as $t){
                $term_name = $t->name;
                $term_link = get_term_link($t->slug,$t->taxonomy);
                array_push($terms_html_array,"<a href='{$term_link}'>{$term_name}</a>");
                array_push($terms_id_array,$t->slug);
                $term_classes .= "um_".$t->slug." ";
            }
            $terms_html_array = implode(", ",$terms_html_array);
            ?>
            <div class="column project_block post_block col-sm-3 mix_all <?php echo $term_classes; ?>" data-filter='<?php echo implode(" ",$terms_id_array); ?> mix_all'>
                <div>
                    <?php the_post_thumbnail("work_post"); ?>
                </div>
                <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                <ul>
                    <?php if($terms_html_array): ?>
                        <li><i class='icon-angle-right'></i><?php echo $terms_html_array; ?></li>
                    <?php endif; ?>
                </ul>
            </div>
        <?php endwhile; wp_reset_postdata(); ?>
    </div>

    <div class="column-2 row filterable">
        <?php
        $arguments = array();
        $arguments["post_type"] = "portfolio";
        $arguments["posts_per_page"] = 4;
        $the_query = new WP_Query( $arguments );
        while ( $the_query->have_posts() ) :  $the_query->the_post();
        $terms = wp_get_post_terms( $post->ID,"portfolio_category" );
        $terms_html_array = array();
        $terms_id_array = array();
        $term_classes = "";
        foreach($terms as $t){
            $term_name = $t->name;
            $term_link = get_term_link($t->slug,$t->taxonomy);
            array_push($terms_html_array,"<a href='{$term_link}'>{$term_name}</a>");
            array_push($terms_id_array,$t->slug);
            $term_classes .= "um_".$t->slug." ";
        }
        $terms_html_array = implode(", ",$terms_html_array);
            ?>
            <div class="column project_block post_block col-sm-6 <?php echo $term_classes; ?>" data-filter='<?php echo implode(" ",$terms_id_array); ?> mix_all'>
                <div>
                    <?php the_post_thumbnail("work_post_medium"); ?>
                </div>
                <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                <ul>
                    <?php if($terms_html_array): ?>
                        <li><i class='icon-angle-right'></i><?php echo $terms_html_array; ?></li>
                    <?php endif; ?>
                </ul>
            </div>
        <?php endwhile;wp_reset_postdata(); ?>
    </div>

    <div class="col-sm-12 load-more-cont">
        <a href="<?php the_permalink(); ?>" class="load-more portfolio_load_more"><?php _e("Load More","um_lang"); ?></a>
    </div>
</div>
<script type="text/javascript">
    jQuery(document).ready(function($){
        $(".filterable").mixitup({
            targetSelector : "div.project_block",
            filterLogic : "and",
            multiFilter : true
        });
    });
    project_page = 1;
</script>
<?php get_footer(); ?>