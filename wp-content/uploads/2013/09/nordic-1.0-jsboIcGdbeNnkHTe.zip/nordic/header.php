<?php if(!isset($_REQUEST["um_ajax_load_site"])): ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
    <?php if(get_field("site_favico","options")): ?>
        <link rel="icon" type="image/png" href="<?php the_field("site_favico","options"); ?>">
    <?php endif; ?>

    <link href="<?php echo get_template_directory_uri();?>/style.css" rel="stylesheet">

    <script type="text/javascript">
        var um_ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
        var home_columns_animation_delay = 200;
        var ajax_site = <?php echo get_field("ajax_site","options") == 'Disabled' ? false : true; ?>;
    </script>
    <?php if(get_field("custom_css","options")): ?>
        <style type="text/css">
            <?php the_field("custom_css","options"); ?>
        </style>
    <?php endif; ?>
    <?php if(get_field("custom_javascript","options")): ?>
        <script type="text/javascript">
            <?php the_field("custom_javascript","options"); ?>
        </script>
    <?php endif; ?>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?> >
<?php if(get_field("ajax_site","options") != 'Disabled'): ?>
<div class="loader">
    <div class="bubblingG">
        <span id="bubblingG_1">
        </span>
        <span id="bubblingG_2">
        </span>
        <span id="bubblingG_3">
        </span>
    </div>
</div>
<?php endif; ?>
<div id="header">
    <div class="site-title">
        <?php if(get_field("site_logo","options")): ?>
        <a href="<?php echo site_url(); ?>" class="logo">
            <img src="<?php the_field("site_logo","options"); ?>" alt="<?php bloginfo("name"); ?>">
        </a>
        <?php endif; ?>
    </div>
    <p class="site-description"><?php bloginfo("description"); ?></p>
    <div class="main-menu-holder">
        <?php wp_nav_menu(array("theme_location" => "main_menu","menu_id"=>"main_menu","menu_class"=>"main_menu")); ?>
    </div>
</div>
<!--Open Inner Content-->
<div id="inner-content">
<?php endif; ?>
<title><?php bloginfo('name'); ?> | <?php if(is_home() || is_front_page()){ bloginfo("description"); } wp_title("",true,""); ?></title>