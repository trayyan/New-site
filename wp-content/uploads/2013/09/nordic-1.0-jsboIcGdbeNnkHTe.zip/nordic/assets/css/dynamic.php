<?php header('Content-Type: text/css; charset: UTF-8'); ?>

<?php if(isset($_GET["font"]) && $_GET["font"]): ?>
    body, a, h1, h2, h3, h4, h5, h6 {
        font-family: '<?php echo $_GET["font"]; ?>', Arial, sans-serif;
    }
<?php endif; ?>

<?php if(isset($_GET["bg_pattern"]) && $_GET["bg_pattern"]): ?>
    body{
        background-image:url('<?php echo $_GET["bg_pattern"]; ?>');
        background-repeat:repeat;
    }
<?php endif; ?>

<?php if(isset($_GET["bg_image"]) && $_GET["bg_image"]): ?>
    body{
        background-image:url('<?php echo $_GET["bg_image"]; ?>');
        background-repeat:no-repeat;
        background-size:cover;
        -webkit-background-size:cover;
        -moz-background-size:cover;
        -o-background-size:cover;
        background-attachment:fixed;
        background-position:center center;
    }
<?php endif; ?>

<?php if(isset($_GET["brand_color"]) && $_GET["brand_color"]): ?>
.post_block ul li i, .um-blog-w.widget ul li p i, .post-content ul.categories li i, .liked *, ul.accordion li a i, ul.toggle li a i, .widget.widget_calendar table a {
color: <?php echo $_GET["brand_color"]; ?> !important;
}

.service:hover .service-icon, .yellow, .yellow:hover, .highlight {
background-color: <?php echo $_GET["brand_color"]; ?> !important;
}
<?php endif; ?>